package com.example.demo.car;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CarReservationServiceImpl implements CarReservationService {

    private final CarReservationRepository carReservationRepository;

    @Autowired
    public CarReservationServiceImpl(CarReservationRepository carReservationRepository) {
        this.carReservationRepository = carReservationRepository;
    }

    @Override
    public List<CarReservation> getAllCarReservations() {
        return carReservationRepository.findAll();
    }

    @Override
    public CarReservation getCarReservationById(Long id) {
        Optional<CarReservation> optionalCarReservation = carReservationRepository.findById(id);
        return optionalCarReservation.orElse(null);
    }

    @Override
    public CarReservation createCarReservation(CarReservation carReservation) {
        return carReservationRepository.save(carReservation);
    }

    @Override
    public CarReservation updateCarReservation(Long id, CarReservation carReservation) {
        if (carReservationRepository.existsById(id)) {
            carReservation.setId(id);
            return carReservationRepository.save(carReservation);
        }
        return null;
    }

    @Override
    public void deleteCarReservation(Long id) {
        carReservationRepository.deleteById(id);
    }
}
