package com.example.demo.room;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface RoomReservationRepository extends JpaRepository<RoomReservation, Long> {
    List<RoomReservation> findByRoomNameAndStartTimeLessThanEqualAndEndTimeGreaterThanEqual(
        String roomName, LocalDateTime startTime, LocalDateTime endTime);
         // Define a method to find overlapping reservations
    @Query("SELECT r FROM RoomReservation r " +
           "WHERE r.roomName = :roomName " +
           "AND ((:startTime BETWEEN r.startTime AND r.endTime) OR " +
           "     (:endTime BETWEEN r.startTime AND r.endTime) OR " +
           "     (r.startTime BETWEEN :startTime AND :endTime))")
    List<RoomReservation> findOverlappingReservations(
            @Param("roomName") String roomName,
            @Param("startTime") LocalDateTime startTime,
            @Param("endTime") LocalDateTime endTime
    );
}