package com.example.demo.room;

import java.util.List;

public interface RoomReservationService {
    List<RoomReservation> getAllRoomReservations();
    RoomReservation getRoomReservationById(Long id);
    RoomReservation createRoomReservation(RoomReservation roomReservation);
    RoomReservation updateRoomReservation(Long id, RoomReservation roomReservation);
    void deleteRoomReservation(Long id);
    boolean isRoomAvailable(RoomReservation roomReservation);
}

