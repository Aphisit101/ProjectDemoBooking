package com.example.demo.car;

import java.util.List;

public interface CarReservationService {
    List<CarReservation> getAllCarReservations();

    CarReservation getCarReservationById(Long id);

    CarReservation createCarReservation(CarReservation carReservation);

    CarReservation updateCarReservation(Long id, CarReservation carReservation);

    void deleteCarReservation(Long id);
}
