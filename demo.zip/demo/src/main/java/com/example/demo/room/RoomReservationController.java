package com.example.demo.room;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/reservations")
public class RoomReservationController {

    private final RoomReservationService roomReservationService;

    @Autowired
    public RoomReservationController(RoomReservationService roomReservationService) {
        this.roomReservationService = roomReservationService;
    }

    @GetMapping
    public String getAllRoomReservations(Model model) {
        List<RoomReservation> roomReservations = roomReservationService.getAllRoomReservations();
        model.addAttribute("roomReservations", roomReservations);
        return "booking_detail"; // Corresponds to booking_detail.html template
    }

    @GetMapping("/create")
    public String showCreateReservationForm(Model model) {
        model.addAttribute("roomReservation", new RoomReservation());
        return "create_reservation"; // Corresponds to create_reservation.html template
    }

    @PostMapping("/create")
    public String createRoomReservation(@ModelAttribute RoomReservation roomReservation) {
        roomReservationService.createRoomReservation(roomReservation);
        return "redirect:/reservations";
    }

    @GetMapping("/edit/{id}")
    public String showEditReservationForm(@PathVariable Long id, Model model) {
        RoomReservation roomReservation = roomReservationService.getRoomReservationById(id);
        if (roomReservation != null) {
            model.addAttribute("roomReservation", roomReservation);
            return "edit_reservation"; // Corresponds to edit_reservation.html template
        } else {
            return "redirect:/reservations";
        }
    }

    @PostMapping("/edit/{id}")
    public String updateRoomReservation(
            @PathVariable Long id,
            @ModelAttribute RoomReservation roomReservation) {
        roomReservationService.updateRoomReservation(id, roomReservation);
        return "redirect:/reservations";
    }

    @GetMapping("/delete/{id}")
    public String deleteRoomReservation(@PathVariable Long id) {
        roomReservationService.deleteRoomReservation(id);
        return "redirect:/reservations";
    }
}