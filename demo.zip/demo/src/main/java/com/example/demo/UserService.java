package com.example.demo;

public interface UserService {

	User save(UserDto userDto);

}
