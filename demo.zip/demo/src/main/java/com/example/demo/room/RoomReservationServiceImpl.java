package com.example.demo.room;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class RoomReservationServiceImpl implements RoomReservationService {

    private final RoomReservationRepository roomReservationRepository;

    @Autowired
    public RoomReservationServiceImpl(RoomReservationRepository roomReservationRepository) {
        this.roomReservationRepository = roomReservationRepository;
    }

    @Override
    public List<RoomReservation> getAllRoomReservations() {
        return roomReservationRepository.findAll();
    }

    @Override
    public RoomReservation getRoomReservationById(Long id) {
        Optional<RoomReservation> optionalRoomReservation = roomReservationRepository.findById(id);
        return optionalRoomReservation.orElse(null);
    }

    @Override
    public RoomReservation createRoomReservation(RoomReservation roomReservation) {
        return roomReservationRepository.save(roomReservation);
    }

    @Override
    public RoomReservation updateRoomReservation(Long id, RoomReservation roomReservation) {
        if (roomReservationRepository.existsById(id)) {
            roomReservation.setId(id);
            return roomReservationRepository.save(roomReservation);
        }
        return null;
    }

    @Override
    public void deleteRoomReservation(Long id) {
        roomReservationRepository.deleteById(id);
    }
}