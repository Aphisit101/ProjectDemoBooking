package com.example.demo.car;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/car-reservations")
public class CarReservationController {

    private final CarReservationService carReservationService;

    @Autowired
    public CarReservationController(CarReservationService carReservationService) {
        this.carReservationService = carReservationService;
    }

    @GetMapping
    public String getAllCarReservations(Model model) {
        List<CarReservation> carReservations = carReservationService.getAllCarReservations();
        model.addAttribute("carReservations", carReservations);
        return "car_booking_detail"; // Corresponds to car_booking_detail.html template
    }

    @GetMapping("/create")
    public String showCreateReservationForm(Model model) {
        model.addAttribute("carReservation", new CarReservation());
        return "car_create_reservation"; // Corresponds to car_create_reservation.html template
    }

    @PostMapping("/create")
    public String createCarReservation(@ModelAttribute CarReservation carReservation) {
        carReservationService.createCarReservation(carReservation);
        return "redirect:/car-reservations";
    }

    @GetMapping("/edit/{id}")
    public String showEditReservationForm(@PathVariable Long id, Model model) {
        CarReservation carReservation = carReservationService.getCarReservationById(id);
        if (carReservation != null) {
            model.addAttribute("carReservation", carReservation);
            return "car_edit_reservation"; // Corresponds to car_edit_reservation.html template
        } else {
            return "redirect:/car-reservations";
        }
    }

    @PostMapping("/edit/{id}")
    public String updateCarReservation(
            @PathVariable Long id,
            @ModelAttribute CarReservation carReservation) {
        carReservationService.updateCarReservation(id, carReservation);
        return "redirect:/car-reservations";
    }

    @GetMapping("/delete/{id}")
    public String deleteCarReservation(@PathVariable Long id) {
        carReservationService.deleteCarReservation(id);
        return "redirect:/car-reservations";
    }
}
